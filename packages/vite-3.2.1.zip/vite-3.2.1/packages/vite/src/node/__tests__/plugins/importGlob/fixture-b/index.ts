export { name as a } from './a'
export { name as b } from './b'
