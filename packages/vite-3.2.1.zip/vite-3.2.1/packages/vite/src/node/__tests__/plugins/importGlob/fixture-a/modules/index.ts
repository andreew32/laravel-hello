export { name as a } from './a'
export { name as b } from './b'

export const name = 'index'

export default 'indexDefault'
