export function hi() {
  return 'hi'
}
