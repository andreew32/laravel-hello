export type { WebSocket, WebSocketAlias } from '../dist/node'
