export type {
  Alias,
  ResolverFunction,
  ResolverObject,
  AliasOptions
} from '../dist/node'
