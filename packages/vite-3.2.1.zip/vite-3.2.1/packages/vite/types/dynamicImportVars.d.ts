export type { RollupDynamicImportVarsOptions } from '../dist/node'
