export type { Terser } from '../dist/node'
