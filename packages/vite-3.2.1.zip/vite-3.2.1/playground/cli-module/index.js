console.log('vite cli in "type":"module" package works!')
