document.querySelector('.raw-js').textContent =
  '[success] Raw js from /public loaded'
