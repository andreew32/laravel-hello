export default class a {
  name = 'a'
}
