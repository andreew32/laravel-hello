function text(el, text) {
  document.querySelector(el).textContent = text
}
text('.relative-js', 'hello')
