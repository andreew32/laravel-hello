module.exports = require('../../vite.config-runtime-base')
