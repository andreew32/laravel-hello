module.exports = require('../../vite.config-relative-base')
