const str: string
export default str
