module.exports = {
  content: [__dirname + '/frontend/**/*.{css,html,ts,js}'],
  theme: {
    extend: {}
  },
  variants: {
    extend: {}
  },
  plugins: []
}
